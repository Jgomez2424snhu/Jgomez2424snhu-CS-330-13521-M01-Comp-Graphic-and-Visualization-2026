///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// default camera settings
	const glm::vec3 g_CameraStartPosition = glm::vec3(0.0f, 5.0f, 12.0f);
	const glm::vec3 g_CameraStartFront = glm::vec3(0.0f, -0.5f, -2.0f);
	const glm::vec3 g_CameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
	const float g_CameraStartZoom = 80.0f;
	const float g_CameraStartSpeed = 20.0f;

	// view volume shared by both projections
	const float g_NearPlane = 0.1f;
	const float g_FarPlane = 100.0f;

	// orthographic view: a fixed, level camera looking at the scene from
	// the front, and half the height of the visible area (wide enough to
	// fit the books and lamp at either end of the desk)
	const glm::vec3 g_OrthoCameraPosition = glm::vec3(0.0f, 1.5f, 12.0f);
	const glm::vec3 g_OrthoCameraTarget = glm::vec3(0.0f, 1.5f, 0.0f);
	const float g_OrthoScale = 6.5f;

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  PrintControls()
 *
 *  This method writes the navigation instructions to the
 *  console so the user knows how to move around the scene.
 ***********************************************************/
static void PrintControls()
{
	std::cout << "\n=========== SCENE CONTROLS ===========\n"
		<< "  W / S        move the camera forward / backward\n"
		<< "  A / D        move the camera left / right\n"
		<< "  Q / E        move the camera up / down\n"
		<< "  Mouse        look around (move the mouse)\n"
		<< "  Scroll wheel change the camera movement speed\n"
		<< "  P            perspective (3D) view\n"
		<< "  O            orthographic (2D) view\n"
		<< "  Esc          close the window\n"
		<< "======================================\n" << std::endl;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = g_CameraStartPosition;
	g_pCamera->Front = g_CameraStartFront;
	g_pCamera->Up = g_CameraUp;
	g_pCamera->Zoom = g_CameraStartZoom;
	g_pCamera->MovementSpeed = g_CameraStartSpeed;

	// tell the user how to move around the scene
	PrintControls();
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;


	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll wheel events,
	// which are used here to control the camera's movement speed
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Wheel_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	// move the 3D camera according to the calculated offsets
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Wheel_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is moved within the active GLFW
 *  display window. It adjusts the camera's movement speed
 *  rather than the lens zoom. The new speed is printed to the
 *  console each time the wheel is moved.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Wheel_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// adjust the camera's movement speed based on the scroll
	// wheel direction
	g_pCamera->ProcessMouseScroll(yOffset);

	// report the new speed so the effect of the scroll is visible
	std::cout << "Camera movement speed: " << g_pCamera->MovementSpeed << std::endl;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// process camera moving forward and backward
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// process camera moving left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}
	// process camera moving upward and downward
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// switch to perspective (3D) projection when P is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		if (bOrthographicProjection)
		{
			std::cout << "Switched to perspective (3D) view" << std::endl;
		}
		bOrthographicProjection = false;
	}
	// switch to orthographic (2D) projection when O is pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		if (!bOrthographicProjection)
		{
			std::cout << "Switched to orthographic (2D) view" << std::endl;
		}
		bOrthographicProjection = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// the aspect ratio of the display window is needed for both
	// the perspective and orthographic projection matrices
	GLfloat aspectRatio = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

	if (bOrthographicProjection == true)
	{
		// for the orthographic (2D) view, the camera looks straight
		// ahead at the scene from a fixed, level position instead of
		// using the free-roaming perspective camera -- looking level
		// (rather than down) at the objects means the ground plane is
		// seen edge-on and is therefore not visible
		view = glm::lookAt(g_OrthoCameraPosition, g_OrthoCameraTarget, g_CameraUp);

		// orthographic projection has no perspective distortion --
		// objects stay the same size regardless of distance
		projection = glm::ortho(
			-g_OrthoScale * aspectRatio, g_OrthoScale * aspectRatio,
			-g_OrthoScale, g_OrthoScale,
			g_NearPlane, g_FarPlane);
	}
	else
	{
		// for the perspective (3D) view, use the free-roaming camera
		// that responds to the keyboard and mouse controls
		view = g_pCamera->GetViewMatrix();

		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom), aspectRatio, g_NearPlane, g_FarPlane);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}