///////////////////////////////////////////////////////////////////////////////
// sceneobject.h
// ============
// encapsulates one real-world object in the 3D scene as a reusable collection
// of basic mesh parts, each with its own transform, surface and material
//
//  AUTHOR: Joseph Gomez
//	Created for CS-330-Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <glm/glm.hpp>

#include <string>
#include <vector>

/***********************************************************
 *  MeshType
 *
 *  The basic mesh shapes that a part of a SceneObject can be
 *  drawn with.
 ***********************************************************/
enum class MeshType
{
	BOX,
	CONE,
	CYLINDER,
	PLANE,
	PRISM,
	PYRAMID4,
	SPHERE,
	TAPERED_CYLINDER,
	TORUS
};

/***********************************************************
 *  ObjectPart
 *
 *  One basic mesh primitive that makes up part of a
 *  SceneObject, along with everything needed to transform,
 *  texture or color, and light it.
 ***********************************************************/
struct ObjectPart
{
	// which basic mesh is drawn for this part
	MeshType shape = MeshType::BOX;

	// transformation values, applied in scale, rotate, translate order
	glm::vec3 scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	glm::vec3 rotationDegreesXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3 positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// a part is drawn with either a texture or a flat color, and
	// bUseTexture decides which of the two is used
	bool bUseTexture = false;
	std::string textureTag;
	glm::vec2 uvScale = glm::vec2(1.0f, 1.0f);
	glm::vec4 color = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f);

	// tag of the material that controls how this part reflects light
	std::string materialTag;
};

/***********************************************************
 *  SceneObject
 *
 *  Represents one complete real-world object in the scene,
 *  such as the mug, the stack of books, or the lamp, built
 *  from one or more ObjectParts. Keeping each object's parts
 *  together in its own class means a multi-shape object is
 *  defined once and handled as a single unit.
 ***********************************************************/
class SceneObject
{
public:
	// constructor - every object is given a descriptive name
	explicit SceneObject(const std::string& name)
		: m_name(name)
	{
	}

	// adds one more basic mesh part to this object
	void AddPart(const ObjectPart& part)
	{
		m_parts.push_back(part);
	}

	// the name this object was created with
	const std::string& GetName() const
	{
		return m_name;
	}

	// all of the parts that make up this object
	const std::vector<ObjectPart>& GetParts() const
	{
		return m_parts;
	}

private:
	// descriptive name of the object
	std::string m_name;
	// the basic mesh parts that make up the object
	std::vector<ObjectPart> m_parts;
};
