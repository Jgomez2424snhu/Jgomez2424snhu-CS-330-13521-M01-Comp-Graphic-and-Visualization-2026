///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

#include <iostream>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	// texture tags - defined once here instead of repeating the same
	// string literals throughout the file, so a tag only ever has to
	// be changed in one place
	const char* g_CeramicTextureTag = "ceramic";
	const char* g_DeskTextureTag = "desk";

	// material tags - same reasoning as the texture tags above
	const char* g_CeramicMaterialTag = "ceramicMaterial";
	const char* g_DeskMaterialTag = "deskMaterial";
	const char* g_BookMaterialTag = "bookMaterial";
	const char* g_LampMaterialTag = "lampMaterial";

	// thickness (tube radius) of the torus mesh, shared by the mug
	// handle and the washi tape roll since only one torus mesh is
	// kept in memory at a time
	const float g_TorusThickness = 0.3f;

	// desk surface dimensions and how many times the wood texture
	// repeats across it
	const glm::vec3 g_DeskScale = glm::vec3(20.0f, 1.0f, 10.0f);
	const glm::vec2 g_DeskTextureRepeat = glm::vec2(6.0f, 3.0f);
}

// helpers and object builders - these only describe objects (shape,
// size, position, surface), they never touch OpenGL directly
namespace
{
	// builds a part drawn with a texture; fallbackColor is used instead
	// if the texture file could not be loaded
	ObjectPart MakeTexturedPart(
		MeshType shape,
		glm::vec3 scaleXYZ,
		glm::vec3 rotationDegreesXYZ,
		glm::vec3 positionXYZ,
		const char* textureTag,
		glm::vec2 uvScale,
		glm::vec4 fallbackColor,
		const char* materialTag)
	{
		ObjectPart part;
		part.shape = shape;
		part.scaleXYZ = scaleXYZ;
		part.rotationDegreesXYZ = rotationDegreesXYZ;
		part.positionXYZ = positionXYZ;
		part.bUseTexture = true;
		part.textureTag = textureTag;
		part.uvScale = uvScale;
		part.color = fallbackColor;
		part.materialTag = materialTag;
		return part;
	}

	// builds a part drawn with a solid color
	ObjectPart MakeColoredPart(
		MeshType shape,
		glm::vec3 scaleXYZ,
		glm::vec3 rotationDegreesXYZ,
		glm::vec3 positionXYZ,
		glm::vec4 color,
		const char* materialTag)
	{
		ObjectPart part;
		part.shape = shape;
		part.scaleXYZ = scaleXYZ;
		part.rotationDegreesXYZ = rotationDegreesXYZ;
		part.positionXYZ = positionXYZ;
		part.bUseTexture = false;
		part.color = color;
		part.materialTag = materialTag;
		return part;
	}

	// mug dimensions - the handle position is derived from these so the
	// handle always stays attached if the mug is resized
	const float g_MugRadius = 1.2f;
	const float g_MugHeight = 2.5f;
	const float g_MugHandleScale = 0.5f;

	// washi tape roll dimensions and position
	const float g_TapeRadius = 0.9f;
	const float g_TapeHeight = 0.36f;
	const glm::vec3 g_TapePosition = glm::vec3(-3.5f, 0.0f, 3.0f);

	// book stack position (the center of the bottom book)
	const glm::vec3 g_BooksPosition = glm::vec3(-5.5f, 0.0f, -1.0f);

	// desk lamp position (the center of its base)
	const glm::vec3 g_LampPosition = glm::vec3(5.5f, 0.0f, -2.0f);

	// one flat desk surface - 1 primitive (plane), textured
	SceneObject BuildDesk()
	{
		SceneObject desk("desk");
		desk.AddPart(MakeTexturedPart(
			MeshType::PLANE,
			g_DeskScale, glm::vec3(0.0f), glm::vec3(0.0f),
			g_DeskTextureTag, g_DeskTextureRepeat,
			glm::vec4(0.45f, 0.3f, 0.18f, 1.0f),
			g_DeskMaterialTag));
		return desk;
	}

	// coffee mug - 2 primitives (cylinder body + torus handle), textured
	SceneObject BuildMug()
	{
		SceneObject mug("mug");

		// the cylinder mesh is 1 unit in radius and height with its base at
		// y = 0, so scaling x/z sets the radius and y sets the height
		mug.AddPart(MakeTexturedPart(
			MeshType::CYLINDER,
			glm::vec3(g_MugRadius, g_MugHeight, g_MugRadius),
			glm::vec3(0.0f), glm::vec3(0.0f),
			g_CeramicTextureTag, glm::vec2(3.0f, 2.0f),
			glm::vec4(0.9f, 0.9f, 0.9f, 1.0f),
			g_CeramicMaterialTag));

		// the torus ring lies in the local XY plane, which is already the
		// orientation a handle needs; it is centered on the mug wall at
		// mid-height so half the loop is embedded in the body
		mug.AddPart(MakeTexturedPart(
			MeshType::TORUS,
			glm::vec3(g_MugHandleScale), glm::vec3(0.0f),
			glm::vec3(g_MugRadius, g_MugHeight / 2.0f, 0.0f),
			g_CeramicTextureTag, glm::vec2(1.0f, 1.0f),
			glm::vec4(0.9f, 0.9f, 0.9f, 1.0f),
			g_CeramicMaterialTag));

		return mug;
	}

	// roll of washi tape lying flat - 1 primitive (torus), solid color
	SceneObject BuildWashiTape()
	{
		SceneObject tape("washiTape");

		// rotating 90 degrees about X lays the ring flat on the desk, and
		// squashing the local Z scale keeps the roll short instead of a
		// full donut; the position lifts it by half its height
		tape.AddPart(MakeColoredPart(
			MeshType::TORUS,
			glm::vec3(g_TapeRadius, g_TapeRadius, g_TapeHeight / (2.0f * g_TorusThickness)),
			glm::vec3(90.0f, 0.0f, 0.0f),
			g_TapePosition + glm::vec3(0.0f, g_TapeHeight / 2.0f, 0.0f),
			glm::vec4(0.95f, 0.55f, 0.65f, 1.0f),
			g_BookMaterialTag));

		return tape;
	}

	// stack of three books, each slightly twisted - 3 primitives (boxes)
	SceneObject BuildBookStack()
	{
		SceneObject books("bookStack");

		// bottom book - large and dark blue
		books.AddPart(MakeColoredPart(
			MeshType::BOX,
			glm::vec3(4.0f, 0.5f, 3.0f), glm::vec3(0.0f, 0.0f, 0.0f),
			g_BooksPosition + glm::vec3(0.0f, 0.25f, 0.0f),
			glm::vec4(0.15f, 0.25f, 0.5f, 1.0f),
			g_BookMaterialTag));

		// middle book - slightly smaller, deep red, turned a little
		books.AddPart(MakeColoredPart(
			MeshType::BOX,
			glm::vec3(3.6f, 0.45f, 2.8f), glm::vec3(0.0f, 10.0f, 0.0f),
			g_BooksPosition + glm::vec3(0.1f, 0.725f, 0.0f),
			glm::vec4(0.55f, 0.15f, 0.15f, 1.0f),
			g_BookMaterialTag));

		// top book - smallest, green, turned the other way
		books.AddPart(MakeColoredPart(
			MeshType::BOX,
			glm::vec3(3.2f, 0.4f, 2.5f), glm::vec3(0.0f, -8.0f, 0.0f),
			g_BooksPosition + glm::vec3(-0.1f, 1.15f, 0.0f),
			glm::vec4(0.2f, 0.45f, 0.25f, 1.0f),
			g_BookMaterialTag));

		return books;
	}

	// desk lamp - 4 primitives (cylinder base, cylinder stem, sphere bulb,
	// cone shade), solid colors
	SceneObject BuildDeskLamp()
	{
		SceneObject lamp("deskLamp");

		// weighted round base
		lamp.AddPart(MakeColoredPart(
			MeshType::CYLINDER,
			glm::vec3(1.0f, 0.3f, 1.0f), glm::vec3(0.0f),
			g_LampPosition,
			glm::vec4(0.2f, 0.2f, 0.22f, 1.0f),
			g_LampMaterialTag));

		// thin vertical stem rising from the base
		lamp.AddPart(MakeColoredPart(
			MeshType::CYLINDER,
			glm::vec3(0.12f, 3.2f, 0.12f), glm::vec3(0.0f),
			g_LampPosition + glm::vec3(0.0f, 0.3f, 0.0f),
			glm::vec4(0.7f, 0.7f, 0.72f, 1.0f),
			g_LampMaterialTag));

		// warm bulb at the top of the stem
		lamp.AddPart(MakeColoredPart(
			MeshType::SPHERE,
			glm::vec3(0.5f), glm::vec3(0.0f),
			g_LampPosition + glm::vec3(0.0f, 3.7f, 0.0f),
			glm::vec4(1.0f, 0.92f, 0.65f, 1.0f),
			g_BookMaterialTag));

		// cone shade capping the bulb
		lamp.AddPart(MakeColoredPart(
			MeshType::CONE,
			glm::vec3(0.9f, 0.9f, 0.9f), glm::vec3(0.0f),
			g_LampPosition + glm::vec3(0.0f, 3.95f, 0.0f),
			glm::vec4(0.85f, 0.8f, 0.7f, 1.0f),
			g_BookMaterialTag));

		return lamp;
	}
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// start with no textures loaded so the texture bookkeeping
	// never begins from uninitialized values
	m_loadedTextures = 0;
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = 0;
	}
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}


/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines how each kind of surface in the scene
 *  reflects light - the diffuse color, the specular color and
 *  the shininess - and stores each one under a tag so objects
 *  can look their material up by name.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// ceramic material for the mug body and handle - a glossy glazed
	// ceramic surface, so it gets a fairly bright, tight specular
	// highlight on top of its diffuse response
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	ceramicMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	ceramicMaterial.shininess = 32.0f;
	ceramicMaterial.tag = g_CeramicMaterialTag;
	m_objectMaterials.push_back(ceramicMaterial);

	// desk material for the wood plane - a satin wood finish, so it
	// takes a modest, broader specular highlight rather than the mug's
	// sharp glassy one
	OBJECT_MATERIAL deskMaterial;
	deskMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	deskMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	deskMaterial.shininess = 8.0f;
	deskMaterial.tag = g_DeskMaterialTag;
	m_objectMaterials.push_back(deskMaterial);

	// book material - a soft matte paper and cloth cover finish, so it
	// barely picks up any specular highlight at all - the washi tape
	// roll uses this too since it is also paper
	OBJECT_MATERIAL bookMaterial;
	bookMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	bookMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	bookMaterial.shininess = 4.0f;
	bookMaterial.tag = g_BookMaterialTag;
	m_objectMaterials.push_back(bookMaterial);

	// lamp material - a brushed metal finish, so it picks up a bright,
	// tight specular highlight with a cooler, more neutral tint than
	// the ceramic
	OBJECT_MATERIAL lampMaterial;
	lampMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	lampMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	lampMaterial.shininess = 48.0f;
	lampMaterial.tag = g_LampMaterialTag;
	m_objectMaterials.push_back(lampMaterial);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method turns on custom lighting and configures the
 *  light sources for the scene. Each light uses all three
 *  Phong components: ambient, diffuse and specular.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// primary light: a warm point light positioned above and in front
	// of the mug, like a desk lamp shining down on the scene - this is
	// what gives the ceramic its highlight and defines the mug's form
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(2.0f, 6.0f, 5.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.05f, 0.05f, 0.05f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.8f, 0.75f, 0.6f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.6f, 0.6f, 0.55f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// secondary light: a dim, cool blue point light behind and above the
	// desk, like light coming in from a window behind the scene - it
	// lights the back and far sides of the objects so they do not fall
	// into darkness when the camera moves around to the back of the desk
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-3.0f, 6.0f, -6.0f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.03f, 0.03f, 0.05f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.25f, 0.3f, 0.45f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.2f, 0.2f, 0.3f));
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// third light: a soft directional fill light shining down across
	// the whole scene so any surface the two point lights miss still has
	// some definition instead of falling into complete shadow
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.3f, -1.0f, -0.3f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.1f, 0.1f, 0.12f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.25f, 0.25f, 0.3f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.1f, 0.1f, 0.1f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// this scene doesn't use a spotlight
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// the remaining point lights (2-4) are left inactive/unset by default
}

/***********************************************************
 *  LoadTextureWithCheck()
 *
 *  This method loads one texture image through CreateGLTexture()
 *  and checks the result. If the image cannot be loaded, a clear
 *  warning is written to the console and false is returned. Any
 *  object part that asks for a texture that failed to load is
 *  drawn with its fallback color instead (see RenderObject), so
 *  a missing file never leaves the scene blank or broken.
 ***********************************************************/
bool SceneManager::LoadTextureWithCheck(const char* filename, std::string tag)
{
	bool bLoaded = CreateGLTexture(filename, tag);

	if (!bLoaded)
	{
		std::cout << "WARNING: texture '" << tag << "' could not be loaded from "
			<< filename << ". Objects using it will be drawn with a solid color instead."
			<< std::endl;
	}

	return bLoaded;
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// define the materials used for lighting the scene's objects
	DefineObjectMaterials();
	// add and configure the light sources for the scene
	SetupSceneLights();

	// load the textures - each load is checked, and the texture tags
	// are the shared constants so they cannot be mistyped later
	LoadTextureWithCheck("textures/ceramic.jpg", g_CeramicTextureTag);
	LoadTextureWithCheck("textures/desk_wood.jpg", g_DeskTextureTag);

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots
	BindGLTextures();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	m_basicMeshes->LoadPlaneMesh();      // desk surface
	m_basicMeshes->LoadCylinderMesh();   // mug body, lamp base and stem
	m_basicMeshes->LoadBoxMesh();        // stacked books
	m_basicMeshes->LoadSphereMesh();     // lamp bulb
	m_basicMeshes->LoadConeMesh();       // lamp shade
	// the torus is loaded last: only one torus mesh exists in memory,
	// and the mug handle and the washi tape roll share it
	m_basicMeshes->LoadTorusMesh(g_TorusThickness);

	// describe every object in the scene
	BuildSceneObjects();
}

/***********************************************************
 *  BuildSceneObjects()
 *
 *  This method defines every object in the scene as a
 *  SceneObject made of basic mesh parts. Each object is built
 *  with its own helper so this method stays short and each
 *  object can be adjusted without touching the others.
 ***********************************************************/
void SceneManager::BuildSceneObjects()
{
	m_sceneObjects.clear();

	m_sceneObjects.push_back(BuildDesk());
	m_sceneObjects.push_back(BuildMug());
	m_sceneObjects.push_back(BuildWashiTape());
	m_sceneObjects.push_back(BuildBookStack());
	m_sceneObjects.push_back(BuildDeskLamp());
}

/***********************************************************
 *  RenderObject()
 *
 *  This method draws every part of one SceneObject. For each
 *  part it applies the transformation, then the texture (or the
 *  fallback color), then the material, and then draws the mesh
 *  that matches the part's shape.
 ***********************************************************/
void SceneManager::RenderObject(const SceneObject& object)
{
	for (const ObjectPart& part : object.GetParts())
	{
		// scale, rotate and translate the part
		SetTransformations(
			part.scaleXYZ,
			part.rotationDegreesXYZ.x,
			part.rotationDegreesXYZ.y,
			part.rotationDegreesXYZ.z,
			part.positionXYZ);

		// use the texture only if it was requested AND actually loaded,
		// otherwise fall back to the part's solid color
		if (part.bUseTexture && FindTextureSlot(part.textureTag) >= 0)
		{
			SetShaderTexture(part.textureTag);
			SetTextureUVScale(part.uvScale.x, part.uvScale.y);
		}
		else
		{
			SetShaderColor(part.color.r, part.color.g, part.color.b, part.color.a);
		}

		SetShaderMaterial(part.materialTag);

		switch (part.shape)
		{
		case MeshType::BOX:              m_basicMeshes->DrawBoxMesh(); break;
		case MeshType::CONE:             m_basicMeshes->DrawConeMesh(); break;
		case MeshType::CYLINDER:         m_basicMeshes->DrawCylinderMesh(); break;
		case MeshType::PLANE:            m_basicMeshes->DrawPlaneMesh(); break;
		case MeshType::PRISM:            m_basicMeshes->DrawPrismMesh(); break;
		case MeshType::PYRAMID4:         m_basicMeshes->DrawPyramid4Mesh(); break;
		case MeshType::SPHERE:           m_basicMeshes->DrawSphereMesh(); break;
		case MeshType::TAPERED_CYLINDER: m_basicMeshes->DrawTaperedCylinderMesh(); break;
		case MeshType::TORUS:            m_basicMeshes->DrawTorusMesh(); break;
		}
	}
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is called once per frame. It simply draws every
 *  object that BuildSceneObjects() defined.
 ***********************************************************/
void SceneManager::RenderScene()
{
	for (const SceneObject& object : m_sceneObjects)
	{
		RenderObject(object);
	}
}
